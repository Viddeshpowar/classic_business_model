package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.dto.OfficeAddressDTO;
import com.cg.entity.Customer;
import com.cg.entity.Office;
import com.cg.exception.NotFoundException;
import com.cg.service.OfficeService;

@RestController
@RequestMapping("/api/v1/office")
public class OfficeController {
	@Autowired
	private OfficeService service;
	
	@PostMapping
	public ResponseEntity<String> addOffice(@RequestBody Office office){
		service.addOffice(office);
		return new ResponseEntity<String>("office details added successfully",HttpStatus.OK);
	}
	
	@GetMapping("/{officeCode}")
	public ResponseEntity<Office> findByCode(@PathVariable String officeCode){
		Office office = service.findByCode(officeCode);
		if(office != null) {
			return new ResponseEntity<Office>(office,HttpStatus.OK);
		}else {
			throw new NotFoundException("Office details not found");
		}
	}
	
	@PutMapping("/{officeCode}/{phoneNo}")
	public ResponseEntity<String> updatePhoneNo(@PathVariable String officeCode, @PathVariable String phoneNo) {
		Office office = service.findByCode(officeCode);
		if(office!=null) {
			service.updatePhoneNo(officeCode, phoneNo);
			return new ResponseEntity<String>("office phone number updated successfully",HttpStatus.OK);
		}else {
			throw new NotFoundException("Office details not found");
		}
	}
	
	@PutMapping("/{officeCode}")
	public ResponseEntity<String> updateOfficeAddress(@PathVariable String officeCode, @RequestBody OfficeAddressDTO officeAddressDTO) {
		Office office = service.findByCode(officeCode);
		if(office!=null) {
			service.updateOfficeAddress(officeCode, officeAddressDTO.getAddressLine1(), officeAddressDTO.getAddressLine2());
			return new ResponseEntity<String>("office address updated successfully",HttpStatus.OK);
		}else {
			throw new NotFoundException("Office details not found");
		}
	}
	
	@GetMapping("/customers/{officeCode}")
	public List<Customer> getAllCustomersOfofficeCode(@PathVariable String officeCode){
		return service.getAllCustomersOfofficeCode(officeCode);
	}
	
	@GetMapping("/cities/{cities}")
	public List<Office> getAllOfficesOfCities(@PathVariable List<String> cities){
		return service.getAllOfficesOfCities(cities);
	}
}
