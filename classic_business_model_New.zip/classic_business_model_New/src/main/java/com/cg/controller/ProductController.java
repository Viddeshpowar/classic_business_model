package com.cg.controller;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.dto.ProductNameSaleAmountDTO;
import com.cg.entity.Product;
import com.cg.exception.NotFoundException;
import com.cg.service.ProductService;

@RestController
@RequestMapping("/api/v1/products")
public class ProductController {

	@Autowired
	private ProductService service;

	@PostMapping
	public ResponseEntity<String> addProduct(@RequestBody Product product) {
		Product addedProduct = service.addProduct(product);
		if (addedProduct != null) {
			return new ResponseEntity<>("Product details added successfully", HttpStatus.CREATED);
		}
		return new ResponseEntity<>("Failed to add product details", HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@PutMapping("/{productCode}/{buyPrice}")
    public ResponseEntity<String> updateBuyPrice(@PathVariable String productCode,@PathVariable BigDecimal buyPrice)
	{
        Product product = service.findByCode(productCode);
        if (product != null) {
        	service.updateBuyPrice(productCode, buyPrice);
			return new ResponseEntity<String>("Product's buy price updated successfully",HttpStatus.OK);
		}else {
			throw new NotFoundException("Product details not found");
		}
	}
	
	@PutMapping("/quantity/{productCode}/{quantityInStock}")
    public ResponseEntity<String> updateQuantityInStock(@PathVariable String productCode,@PathVariable short quantityInStock)
	{
        Product product = service.findByCode(productCode);
        if (product != null) {
        	service.updateQuantityInStock(productCode, quantityInStock);
			return new ResponseEntity<String>("product’s quantity updated successfully",HttpStatus.OK);
		}else {
			throw new NotFoundException("Product details not found");
		}
	}
	
	@PutMapping("/msrp/{productCode}/{msrp}")
    public ResponseEntity<String> updateMsrp(@PathVariable String productCode,@PathVariable BigDecimal msrp)
	{
        Product product = service.findByCode(productCode);
        if (product != null) {
        	service.updateMsrp(productCode, msrp);
			return new ResponseEntity<String>("product’s MSRP updated successfully",HttpStatus.OK);
		}else {
			throw new NotFoundException("Product details not found");
		}
	}
	
	@PutMapping("/productVendor/{productCode}/{productVendor}")
    public ResponseEntity<String> updateProductVendor(@PathVariable String productCode,@PathVariable String productVendor)
	{
        Product product = service.findByCode(productCode);
        if (product != null) {
        	service.updateProductVendor(productCode, productVendor);
			return new ResponseEntity<String>("product’s vendor updated successfully",HttpStatus.OK);
		}else {
			throw new NotFoundException("Product details not found");
		}
	}
	
	@PutMapping("/productScale/{productCode}/{productScale}")
    public ResponseEntity<String> updateProductScale(@PathVariable String productCode,@PathVariable String productScale)
	{
        Product product = service.findByCode(productCode);
        if (product != null) {
        	service.updateProductScale(productCode, productScale);
			return new ResponseEntity<String>("product’s scale updated successfully",HttpStatus.OK);
		}else {
			throw new NotFoundException("Product details not found");
		}
	}
	
	@PutMapping("/productName/{productCode}/{productName}")
    public ResponseEntity<String> updateProductName(@PathVariable String productCode,@PathVariable String productName)
	{
        Product product = service.findByCode(productCode);
        if (product != null) {
        	service.updateProductName(productCode, productName);
			return new ResponseEntity<String>("product’s name updated successfully",HttpStatus.OK);
		}else {
			throw new NotFoundException("Product details not found");
		}
	}
	
	
	@GetMapping("/{productCode}")
    public ResponseEntity<Product> getByCode(@PathVariable String productCode) {
		Product product = service.findByCode(productCode);
        if (product != null) {
            return new ResponseEntity<Product>(product, HttpStatus.OK);
        }else {
			throw new NotFoundException("Product details not found");
		}
	}


	@GetMapping("/byname/{productName}")
	public ResponseEntity<?> getProductsByName(@PathVariable String productName) {
		List<Product> products = service.getProductsByName(productName);
		if (!products.isEmpty()) {
			return new ResponseEntity<>(products, HttpStatus.OK);
		}
		return new ResponseEntity<>("Product Details not found", HttpStatus.NOT_FOUND);
	}

	@GetMapping("/byscale/{productScale}")
	public ResponseEntity<?> getProductsByScale(@PathVariable String productScale) {
	    List<Product> products = service.getProductsByScale(productScale);
	    if (!products.isEmpty()) {
	        return new ResponseEntity<>(products, HttpStatus.OK);
	    }
	    return new ResponseEntity<>("No products found for the specified scale", HttpStatus.NOT_FOUND);
	}

	@GetMapping("/byvendor/{productVendor}")
	public ResponseEntity<?> getProductsByVendor(@PathVariable String productVendor) {
		List<Product> products = service.getProductsByVendor(productVendor);
		if (!products.isEmpty()) {
			return new ResponseEntity<>(products, HttpStatus.OK);
		}
		return new ResponseEntity<>("Product Details not found", HttpStatus.NOT_FOUND);
	}

	@GetMapping("/{productCode}/totalOrderedQty")
	public ResponseEntity<?> getTotalOrderedQuantity(@PathVariable String productCode) {
		Product product = service.findByCode(productCode);
		if (product != null) {
			return new ResponseEntity<>(product.getQuantityInStock(), HttpStatus.OK);
		}
		return new ResponseEntity<>("Product Details not found", HttpStatus.NOT_FOUND);
	}
	
	
	@GetMapping("/{productCode}/total_sale")
    public ResponseEntity<BigDecimal> getTotalSaleAmountForProduct(@PathVariable String productCode) {
        BigDecimal totalAmount = service.getTotalSaleAmountForProduct(productCode);
        if (totalAmount.equals(0)) {
        	return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        } else {
        	return new ResponseEntity<BigDecimal>(totalAmount, HttpStatus.OK);
        }
    }
	
	@GetMapping("/total_sale")
    public List<ProductNameSaleAmountDTO> getTotalSaleAmountForEachProducts() {
		List<ProductNameSaleAmountDTO> productAmount = service.getTotalSaleAmountForEachProducts();
		return productAmount;
    }
	
	
	@GetMapping("/product_details")
	public ResponseEntity<List<Product>> getHighlyDemandedProducts() {
		List<Product> products = service.getHighlyDemandedProducts();
		if (products != null) {
			return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
		}
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}
}