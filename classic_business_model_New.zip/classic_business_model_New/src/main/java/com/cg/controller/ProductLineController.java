package com.cg.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.ProductLine;
import com.cg.service.ProductLineService;

@RestController
@RequestMapping("/api/v1/productlines")
public class ProductLineController {

	@Autowired
	private ProductLineService service;

	
	@PostMapping
    public ResponseEntity<String> addNewProductLine(@RequestBody ProductLine productLine) {
        ProductLine savedProductLine = service.addNewProductLine(productLine);
        
        if (savedProductLine != null) {
            return ResponseEntity.status(HttpStatus.CREATED).body("Product line details added successfully");
            
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to add product line");
        }
    }

	
	@PutMapping("/{productLine}/{textDescription}")
	public ResponseEntity<String> updateTextDescriptionOfProductLine(@PathVariable String productLine, @PathVariable String textDescription) {

		service.updateTextDescriptionByProductLine(productLine, textDescription);

		return new ResponseEntity<String>("Products text description updated successfully",HttpStatus.OK);
	}

}
