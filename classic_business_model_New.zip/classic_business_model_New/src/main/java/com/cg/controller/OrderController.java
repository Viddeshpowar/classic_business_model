package com.cg.controller;

import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.dto.CustomerOrderDTO;
import com.cg.dto.ProductProductLineDTO;
import com.cg.entity.Order;
import com.cg.entity.OrderDetail;
import com.cg.entity.Product;
import com.cg.service.OrderService;

@RestController

@RequestMapping("/api/v1/orders")

public class OrderController {

	@Autowired

	private OrderService service;

	@PostMapping("/add")
	public ResponseEntity<Order> addOrder(@RequestBody Order order) {
		Order addedOrder = service.addOrder(order);
		return ResponseEntity.status(HttpStatus.CREATED).body(addedOrder);
	}

	@PutMapping("/{orderNumber}/{shippedDate}")
	public ResponseEntity<String> updateShippedDate(@PathVariable Integer orderNumber, @PathVariable Date shippedDate) {
		Order order = service.updateOrderShippedDate(orderNumber, shippedDate);
		if (order != null) {
			return new ResponseEntity<String>("Order’s shipped date updated Successfully", HttpStatus.FOUND);
		}
		else {
			return new ResponseEntity<String>("Order Details not found", HttpStatus.NOT_FOUND);
		}
	}

	@PutMapping("/{orderNumber}")
	public ResponseEntity<String> updateStatus(@PathVariable Integer orderNumber, @RequestBody String status) {
		Order order = service.updateOrderStatus(orderNumber, status);
		if (order != null) {
			return new ResponseEntity<String>("Order status updated Successfully", HttpStatus.FOUND);
		}
		else {
			return new ResponseEntity<String>("Order Details not found", HttpStatus.NOT_FOUND);
		}
	}
	
	
	@GetMapping("customer/{customerNumber}")
	public List<CustomerOrderDTO> getOrdersByCustomerNumber(@PathVariable int customerNumber){
		return service.getOrdersByCustomerNumber(customerNumber);
	}
	
	
	@GetMapping("/{customerNumber}/{status}")
	public List<OrderDetail> getOrderDetailsByStatusForCustomer(@PathVariable int customerNumber, @PathVariable String status){
		return service.getOrderDetailsByStatusForCustomer(customerNumber, status);
	}
	
	
	@GetMapping("/Id/{orderNumber}")
	public ResponseEntity<Order> getOrderBy(@PathVariable Integer orderNumber) {
		Order order = service.getById(orderNumber);
		if (order != null) {
			return new ResponseEntity<Order>(order, HttpStatus.FOUND);
		}
		else {
			return new ResponseEntity<Order>(HttpStatus.NOT_FOUND);
		}
	}

	@GetMapping("/order/{orderDate}")
	public ResponseEntity<List<Order>> getOrdersByOrderDate(@PathVariable Date orderDate) {
		List<Order> list = service.getOrdersByOrderDate(orderDate);
		if (list.isEmpty()) {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		} else {
			return new ResponseEntity<List<Order>>(list, HttpStatus.FOUND);
		}
	}

	@GetMapping("/req/{requiredDate}")
	public ResponseEntity<List<Order>> getOrderByRequiredDate(@PathVariable Date requiredDate) {
		List<Order> list = service.getOrdersByRequiredDate(requiredDate);
		if (list.isEmpty()) {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		} else {
			return new ResponseEntity<List<Order>>(list, HttpStatus.FOUND);
		}
	}

	@GetMapping("/shipped/{shippedDate}")
	public ResponseEntity<List<Order>> getOrderDetailByShippedDate(@PathVariable Date shippedDate) {
		List<Order> list = service.getOrdersByShippedDate(shippedDate);
		if (list.isEmpty()) {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		} else {
			return new ResponseEntity<List<Order>>(list, HttpStatus.FOUND);
		}
	}

	@GetMapping("/status/{status}")
	public ResponseEntity<List<OrderDetail>> getOrderDetailByOrderStatus(@PathVariable String status) {
		List<OrderDetail> list = service.getOrdersByStatus(status);
		if (list.isEmpty()) {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		} else {
			return new ResponseEntity<List<OrderDetail>>(list, HttpStatus.FOUND);
		}
	}
	
	@GetMapping("/{orderNumber}/products")
	public ResponseEntity<List<Product>> getProductByOrderNumber(@PathVariable int orderNumber){
		List<Product> plist = service.getProductByOrderNumber(orderNumber);
		return new ResponseEntity<List<Product>>(plist, HttpStatus.OK);
	}
	
	@GetMapping("orderNumber/{orderNumber}/products")
	public ResponseEntity<List<String>> getProductNamesByOrderNumber(@PathVariable int orderNumber){
		List<String> plist = service.getProductNamesByOrderNumber(orderNumber);
		return new ResponseEntity<List<String>>(plist, HttpStatus.OK);
	}
	
	@GetMapping
	public ResponseEntity<List<Product>> getAllProductsForAllOrders(){
		List<Product> plist = service.getAllProductsForAllOrders();
		return new ResponseEntity<List<Product>>(plist, HttpStatus.OK);
	}
	
	@GetMapping("/{status}/orders")
	public ResponseEntity<List<Order>> getAllOrdersWithStatusAndSameShippedAndDeliveredDate(@PathVariable String status){
		List<Order> olist = service.getAllOrdersWithStatusAndSameShippedAndDeliveredDate(status);
		return new ResponseEntity<List<Order>>(olist,HttpStatus.OK);
	}
	
	@GetMapping("/product_and_product_line_details/{date}")
	public List<ProductProductLineDTO> getAllProductWithProductLineOnSpecificShippedDate(@PathVariable Date date){
		return service.getAllProductWithProductLineOnSpecificShippedDate(date);
	}

}
