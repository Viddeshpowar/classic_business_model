package com.cg.controller;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.OrderDetail;
import com.cg.service.OrderDetailService;

@RestController
@RequestMapping("/api/v1/orderdetails")
public class OrderDetailController {
	@Autowired
	private OrderDetailService service;
	
	
	@PostMapping("/add")
	public ResponseEntity<String> addOrderDetails(@RequestBody OrderDetail orderDetail) {
		service.addOrderDetails(orderDetail);
		return new ResponseEntity<String>("Record Created Successfully",HttpStatus.OK);
	}
	
	
	@PutMapping("/{orderNumber}/{productCode}/{quantityOrdered}")
	public ResponseEntity<String> updateQuantityOfOrderProduct(@PathVariable int orderNumber, @PathVariable String productCode, @PathVariable int quantityOrdered){
		service.updateQuantityOfOrderProduct(orderNumber, productCode, quantityOrdered);
		return new ResponseEntity<String>("product Quantity updated successfully",HttpStatus.OK);
	}
	
	@GetMapping("/{orderNumber}")
    public ResponseEntity<List<OrderDetail>> getByOrderNumber(@PathVariable int orderNumber) {
		List<OrderDetail> orderDetails = service.getByOrderNumber(orderNumber);
	    HttpStatus status = !orderDetails.isEmpty() ? HttpStatus.OK : HttpStatus.NOT_FOUND;
	    return ResponseEntity.status(status).body(orderDetails);      
    }
	
	@GetMapping("/amountByOrderNumber/{orderNumber}")
    public ResponseEntity<BigDecimal> getAmountByOrderNumber(@PathVariable int orderNumber) {
        BigDecimal amounts = service.getTotalAmountByOrderNumber(orderNumber);
        return ResponseEntity.ok(amounts);
    }
	
	@GetMapping("/totalSale")
    public ResponseEntity<Integer> getTotalSale() {
        int totalSale = service.getByTotalSale();
        return ResponseEntity.ok(totalSale);
    }
	
	@GetMapping("/max/price")
    public ResponseEntity<BigDecimal> getMaxPriceOrderDetail() {
        BigDecimal maxPrice = service.getOrderDetailsByMaxPriceOrder();
        return ResponseEntity.ok(maxPrice);
    }
	
	 @GetMapping("/countByOrderNumber/{orderNumber}")
	    public ResponseEntity<Integer> getOrderDetailCountByOrderNumber(@PathVariable int orderNumber) {
	        int count = service.getOrderDetailCountByOrderNumber(orderNumber);
	        return ResponseEntity.ok(count);
	    }
}

