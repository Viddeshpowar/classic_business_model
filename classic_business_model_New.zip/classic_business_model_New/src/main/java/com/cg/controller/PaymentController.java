package com.cg.controller;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.dto.PaymentCustomerDTO;
import com.cg.entity.Customer;
import com.cg.entity.Office;
import com.cg.entity.Payment;
import com.cg.service.PaymentService;

@RestController
@RequestMapping("/api/v1/payments")
public class PaymentController {
	@Autowired
	private PaymentService service;
	
	@GetMapping("/{customerNumber}")
	public List<PaymentCustomerDTO> findByCustomerNumber(@PathVariable int customerNumber){
		return service.findByCustomerNumber(customerNumber);
	}
	
	
	@GetMapping("/customer-payment/{customerNumber}")
    public ResponseEntity<List<Map<String, Object>>> getCustomerPaymentDetails(@PathVariable int customerNumber) {
		List<Map<String, Object>> customerPaymentList = service.findCustomerPaymentByCustomerNumber(customerNumber);

		if (!customerPaymentList.isEmpty()) {
            return ResponseEntity.ok(customerPaymentList);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
	
	@PutMapping("/{customerNumber}/{checkNumber}/{newCheckNumber}")
	public ResponseEntity<String> updateCheckNumberOfCustomer(@PathVariable int customerNumber, @PathVariable String checkNumber, @PathVariable String newCheckNumber) {
		service.updateCheckNumberOfCustomer(customerNumber, checkNumber, newCheckNumber);
//		Payment payment = service.getByCustomerNumberAndCheckNumber(customerNumber, newCheckNumber);
		return new ResponseEntity<String>("Check number updated Successfully",HttpStatus.OK);
	}
	
	@PutMapping("amount/{customerNumber}/{checkNumber}/{amount}")
	public ResponseEntity<String> updateAmountOfCheckNumber(@PathVariable int customerNumber, @PathVariable String checkNumber, @PathVariable BigDecimal amount) {
		service.updateAmountOfCheckNumber(customerNumber, checkNumber, amount);
		return new ResponseEntity<String>("Payment amount details updated Successfully",HttpStatus.OK);
	}
	
	@GetMapping("/paybydate/{paymentDate}")
	public List<Payment> findByPaymentDate(@PathVariable Date paymentDate){
		return service.findByPaymentDate(paymentDate);
	}
	
	@GetMapping("/paybycheck/{checkNumber}")
	public Payment findByCheckNumber(@PathVariable String checkNumber) {
		return service.findByCheckNumber(checkNumber);
	}
	
	@GetMapping("/totalAmount/{customerNumber}")
	public BigDecimal getTotalAmountByCustomerNumber(@PathVariable int customerNumber) {
		return service.getTotalAmountByCustomerNumber(customerNumber);
	}
	
	
	@GetMapping("/customers/{checkNumber}")
	public List<Customer> getCustomerByCheckNumber(@PathVariable String checkNumber){
		return service.getCustomerByCheckNumber(checkNumber);
	}
	
	
	@GetMapping("/customers/maxamount")
	public Customer getCustomerByMaxAmount() {
		return service.getCustomerByMaxAmount();
	}
	
	@GetMapping("/customers/{startDate}/{endDate}")
	public List<Customer> getCustomerByPaymentDateRange(@PathVariable Date startDate, @PathVariable Date endDate){
		return service.getCustomerByPaymentDateRange(startDate, endDate);
	}
	
	@GetMapping("/{paymentDate}/customers")
	public List<Customer> getCustomerByPaymentDate(@PathVariable Date paymentDate){
		return service.getCustomerByPaymentDate(paymentDate);
	}
	
	@GetMapping("/highest_collection_office_details")
	public List<Office> getOfficeDetailsByMaxPaymentCollection(){
		return service.getOfficeDetailsByMaxPaymentCollection();
	}
	
	//extra
	@GetMapping("/{customerNumber}/{checkNumber}")
	public Payment getByCustomerNumberAndCheckNumber(@PathVariable int customerNumber, @PathVariable String checkNumber) {
		return service.getByCustomerNumberAndCheckNumber(customerNumber, checkNumber);
	}
	
	
	
	

	
	
}
