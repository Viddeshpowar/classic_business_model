package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.Employee;
import com.cg.exception.NotFoundException;
import com.cg.service.EmployeeService;

@RestController
@RequestMapping("/api/v1/employee")
public class EmployeeController {
	@Autowired
	private EmployeeService service;
	
	@PostMapping
	public ResponseEntity<String> createEmployee(@RequestBody Employee employee){
		service.createEmployee(employee);
		return new ResponseEntity<String> ("Employee details added successfully",HttpStatus.OK);
	}
	
	@PutMapping("/{employe_no}/reports_to/{new_employee_no}")
	public ResponseEntity<String> updateReporting(@PathVariable int employe_no, @PathVariable int new_employee_no){
		Employee e = service.findById(new_employee_no);
		if(e != null) {
			service.updateReporting(employe_no, new_employee_no);
			return new ResponseEntity<String> ("details updated Successfully",HttpStatus.OK);
		}else {
			throw new NotFoundException("Employee details not found");
		}
	}

	@PutMapping("/{empid}/role/{role}")
	public ResponseEntity<Employee> updateRole(@PathVariable int empid, @PathVariable String role){
		Employee e = service.findById(empid);
		if(e!=null) {
			Employee emp = service.updateRole(empid, role);
			return new ResponseEntity<Employee>(emp,HttpStatus.OK);
		}else {
			throw new NotFoundException("Employee details not found");
		}
	}
	
	@PutMapping("/{empid}/mapToOffice/{officeCode}")
	public ResponseEntity<Employee> assignOffice(@PathVariable int empid,@PathVariable String officeCode) {
		Employee e = service.findById(empid);
		if(e!=null) {
			Employee emp = service.assignOffice(empid, officeCode);
			return new ResponseEntity<Employee>(emp,HttpStatus.OK);
		}else {
			throw new NotFoundException("Employee details not found");
		}
	}
	

	@GetMapping("/{empid}")
	public Employee findById(@PathVariable int empid) {
		Employee emp = service.findById(empid);
		if(emp!=null) {
			return emp;
		}else {
			throw new NotFoundException("Employee details not found");
		}
	}

	@GetMapping("/all_employee_details")
	public List<Employee> getAll(){
		return service.getAll();
	}
	
	@GetMapping("all_employee_details/{officeCode}")
	public List<Employee> getByOfficeCode(@PathVariable String officeCode){
		if(service.getByOfficeCode(officeCode).size() > 0) {
			return service.getByOfficeCode(officeCode);
		}else {
			throw new NotFoundException("Office details not found");
		}
		
	}
	
	@GetMapping("all_employee_details/city/{city}")
	public List<Employee> getByCity(@PathVariable String city){
		if(service.getByCity(city).size() > 0) {
			return service.getByCity(city);
		}else {
			throw new NotFoundException("Office details not found");
		}
	}
}
