package com.cg.controller;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.dto.OfficeAddressDTO;
import com.cg.entity.Customer;
import com.cg.service.CustomerService;

@RestController
@RequestMapping("/api/v1/customers")
public class CustomerController {
	@Autowired
	private CustomerService service;
	
	@GetMapping("/{empId}")
	public List<Customer> findByEmployeeNumber(@PathVariable int empId){
		return service.findByEmployeeNumber(empId);
	}
	
	@PostMapping
	public Customer addCustomer(@RequestBody Customer customer) {
		return service.addCustomer(customer);
	}
	
	@GetMapping("/customerName/{customerName}")
	public List<Customer> findByCustomerName(@PathVariable String customerName){
		return service.findByCustomerName(customerName);
	}
	
	@GetMapping("/customers/city/{city}")
    public List<Customer> findByCity(@PathVariable String city){
    	return service.findByCity(city);
    }
    
	@GetMapping("/customer_number/{customerNumber}")
	public Customer findByCustomerNumber(@PathVariable int customerNumber) {
		return service.findByCustomerNumber(customerNumber);
	}
	
	@GetMapping("/sales_rep_employee_number/{salesRepEmployeeNumber}")
	public List<Customer> findBySalesRepEmployeeNumber(@PathVariable int salesRepEmployeeNumber){
		return service.findBySalesRepEmployeeNumber(salesRepEmployeeNumber);
	}
	
	@GetMapping("/city/{city}")
	public List<Customer> findCustomerByCity(@PathVariable String city){
		return service.findByCity(city);
	}
	
	@GetMapping("/country/{country}")
	public List<Customer> findByCountry(@PathVariable String country){
		return service.findByCountry(country);
	}
	
	@GetMapping("/phone/{phone}")
	public Customer findByPhoneNumber(@PathVariable String phone) {
		return service.findByPhoneNumber(phone);
	}
	
	@GetMapping("/contact_firstname/{contactFirstName}")
	public List<Customer> findByContactFirstName(@PathVariable String contactFirstName){
		return service.findByContactFirstName(contactFirstName);
	}
	
	@GetMapping("/contact_lastname/{contactLastName}")
	public List<Customer> findByContactLastName(@PathVariable String contactLastName){
		return service.findByContactLastName(contactLastName);
	}
	
	@PutMapping("/{customerNumber}/{customerName}")
	public Customer updateNameOfCustomer(@PathVariable int customerNumber,@PathVariable String customerName) {
		return service.updateNameOfCustomer(customerNumber, customerName);
	}
	
	@PutMapping("/last/{customerNumber}/{contactLastName}")
	public Customer updateLastNameOfCustomer(@PathVariable int customerNumber,@PathVariable String contactLastName) {
		return service.updateLastNameOfCustomer(customerNumber, contactLastName);
	}
	
	@PutMapping("/first/{customerNumber}/{contactFirstName}")
	public Customer updateFirstNameOfCustomer(@PathVariable int customerNumber,@PathVariable String contactFirstName) {
		return service.updateFirstNameOfCustomer(customerNumber, contactFirstName);
	}
	
	@PutMapping("/{customerNumber}")
	public Customer updateAddressOfCustomer(@PathVariable int customerNumber,@RequestBody OfficeAddressDTO officeAddressDTO) {
		return service.updateAddressOfCustomer(customerNumber,officeAddressDTO.getAddressLine1() , officeAddressDTO.getAddressLine2());
	}
	
	@GetMapping("/credit_limit/{creditLimit}")
	public List<Customer> findByCreditLimit(@PathVariable BigDecimal creditLimit){
		return service.findByCreditLimit(creditLimit);
	}
	
	@GetMapping("/postal_code/{postalCode}")
	public List<Customer> findByPostalCode(@PathVariable String postalCode){
		return service.findByPostalCode(postalCode);
	}
	
	@GetMapping("/credit_range/{start}/{end}")
	public List<Customer> findByCreditRange(@PathVariable BigDecimal start, @PathVariable BigDecimal end){
		return service.findByCreditRange(start, end);
	}
	
	
//	public List<Customer> findByPageNo(PageSize pageno sortBy sortDir);
	
	@GetMapping("/getbyfirstnamelike/{customerName}")
	public List<Customer> getByFirstName(@PathVariable String customerName){
		return service.findByCustomerName(customerName);
	}
	
	@GetMapping("/gt/{creditLimit}")
	public List<Customer> getByGreaterCreditLimit(@PathVariable BigDecimal creditLimit){
		return service.getByGreaterCreditLimit(creditLimit);
	}
	@GetMapping("/lt/{creditLimit}")
	public List<Customer> getByLowerCreditLimit(@PathVariable BigDecimal creditLimit){
		return service.getByLowerCreditLimit(creditLimit);
	}
}
