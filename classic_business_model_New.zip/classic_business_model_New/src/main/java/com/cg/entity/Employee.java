package com.cg.entity;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;


@Entity
@Table(name = "employees")
public class Employee {
	@Id
	@Column(name="employeeNumber")
	private int employeeNumber;
	
	@NotNull
	@Column(name="lastName", length = 50)
	private String lastName;
	
	
	@NotNull
	@Column(name="firstName", length = 50)
	private String firstName;
	
	@NotNull
	@Column(name="extension", length = 10)
	private String extension;
	
	@NotNull
	@Column(name="email", length = 100)
	private String email;
	
	//for office
//	@ManyToOne(fetch = FetchType.EAGER)
//	@JoinColumn(name = "officeCode", foreignKey = @ForeignKey(name = "employees_ibfk_2"))
//	@JsonBackReference
//	private Office offices;
	
	@NotNull
	@ManyToOne
    @JoinColumn(name = "officeCode", referencedColumnName = "officeCode")
	@JsonBackReference(value = "offices-employees")
	private Office offices;
	
	//self relationship
	@OneToMany(mappedBy = "reportsTo", cascade = CascadeType.ALL)
	@JsonIgnore
	private List<Employee> reports;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "reportsTo")
	@JsonBackReference(value = "reports-reportsTo")
	private Employee reportsTo;
	
	@NotNull
	@Column(name="jobTitle",length = 50)
	private String jobTitle;

	
	//for customers
	@OneToMany(mappedBy = "salesRepEmployeeNumber")
	@JsonManagedReference(value = "employees-customers")
	private List<Customer> customers;
	
	public Employee() {
		super();
	}

	public Employee(int employeeNumber, String lastName, String firstName, String extension, String email,
			Office offices, List<Employee> reports, Employee reportsTo, String jobTitle, List<Customer> customers) {
		super();
		this.employeeNumber = employeeNumber;
		this.lastName = lastName;
		this.firstName = firstName;
		this.extension = extension;
		this.email = email;
		this.offices = offices;
		this.reports = reports;
		this.reportsTo = reportsTo;
		this.jobTitle = jobTitle;
		this.customers = customers;
	}

	public int getEmployeeNumber() {
		return employeeNumber;
	}

	public void setEmployeeNumber(int employeeNumber) {
		this.employeeNumber = employeeNumber;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getExtension() {
		return extension;
	}

	public void setExtension(String extension) {
		this.extension = extension;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Office getOffices() {
		return offices;
	}

	public void setOffices(Office offices) {
		this.offices = offices;
	}

	public List<Employee> getReports() {
		return reports;
	}

	public void setReports(List<Employee> reports) {
		this.reports = reports;
	}

	public Employee getReportsTo() {
		return reportsTo;
	}

	public void setReportsTo(Employee reportsTo) {
		this.reportsTo = reportsTo;
	}

	public String getJobTitle() {
		return jobTitle;
	}

	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}

	public List<Customer> getCustomers() {
		return customers;
	}

	public void setCustomers(List<Customer> customers) {
		this.customers = customers;
	}

	@Override
	public String toString() {
		return "Employee [employeeNumber=" + employeeNumber + ", lastName=" + lastName + ", firstName=" + firstName
				+ ", extension=" + extension + ", email=" + email + ", offices=" + offices + ", reports=" + reports
				+ ", reportsTo=" + reportsTo + ", jobTitle=" + jobTitle + ", customers=" + customers + "]";
	}
	
	
}
