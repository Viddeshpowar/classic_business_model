package com.cg.entity;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

@Entity
@Table(name = "products")
public class Product {
	@Id
	@Column(name = "productCode", length = 15)
	private String productCode;
	
	@NotNull
	@Column(name = "productName", length = 70)
	private String productName;
	
	@NotNull
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "productLine")
	@JsonBackReference
	private ProductLine productlines;
	
	@NotNull
	@Column(name = "productScale",length = 10)
	private String productScale;
	
	@NotNull
	@Column(name = "productVendor",length = 50)
	private String productVendor;
	
	@NotNull
	@Column(name = "productDescription", columnDefinition = "TEXT")
	private String productDescription;
	
	@NotNull
	@Column(name = "quantityInStock")
	private short quantityInStock;
	
	@NotNull
	@Column(name = "buyPrice", precision = 10, scale = 2)
	private BigDecimal buyPrice;
	
	@NotNull
	@Column(name = "MSRP", precision = 10, scale = 2)
	private BigDecimal msrp;
	
	public Product() {
		super();
	}

	public Product(String productCode, @NotBlank String productName, ProductLine productlines,
			@NotBlank String productScale, @NotBlank String productVendor, @NotBlank String productDescription,
			@NotNull short quantityInStock, @NotNull BigDecimal buyPrice, @NotNull BigDecimal msrp) {
		super();
		this.productCode = productCode;
		this.productName = productName;
		this.productlines = productlines;
		this.productScale = productScale;
		this.productVendor = productVendor;
		this.productDescription = productDescription;
		this.quantityInStock = quantityInStock;
		this.buyPrice = buyPrice;
		this.msrp = msrp;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public ProductLine getProductlines() {
		return productlines;
	}

	public void setProductlines(ProductLine productlines) {
		this.productlines = productlines;
	}

	public String getProductScale() {
		return productScale;
	}

	public void setProductScale(String productScale) {
		this.productScale = productScale;
	}

	public String getProductVendor() {
		return productVendor;
	}

	public void setProductVendor(String productVendor) {
		this.productVendor = productVendor;
	}

	public String getProductDescription() {
		return productDescription;
	}

	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}

	public short getQuantityInStock() {
		return quantityInStock;
	}

	public void setQuantityInStock(short quantityInStock) {
		this.quantityInStock = quantityInStock;
	}

	public BigDecimal getBuyPrice() {
		return buyPrice;
	}

	public void setBuyPrice(BigDecimal buyPrice) {
		this.buyPrice = buyPrice;
	}

	public BigDecimal getMsrp() {
		return msrp;
	}

	public void setMsrp(BigDecimal msrp) {
		this.msrp = msrp;
	}

	@Override
	public String toString() {
		return "Product [productCode=" + productCode + ", productName=" + productName + ", productlines=" + productlines
				+ ", productScale=" + productScale + ", productVendor=" + productVendor + ", productDescription="
				+ productDescription + ", quantityInStock=" + quantityInStock + ", buyPrice=" + buyPrice + ", msrp="
				+ msrp + "]";
	}
}
