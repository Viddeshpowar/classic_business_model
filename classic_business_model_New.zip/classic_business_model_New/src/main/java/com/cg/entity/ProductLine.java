package com.cg.entity;

import java.util.Arrays;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotEmpty;

@Entity
@Table(name = "productlines")
public class ProductLine {
	@Id
	@Column(name = "productLine", length = 50)
	private String productLine;
	
	@Column(name = "textDescription", length = 4000)
	private String textDescription;
	
	@Column(name = "htmlDescription", columnDefinition = "MEDIUMTEXT")
	private String htmlDescription;
	
	@Column(name = "image", columnDefinition = "MEDIUMBLOB")
	private byte[] image;
	
	@NotEmpty
	@OneToMany(mappedBy = "productlines", fetch = FetchType.LAZY)
	@JsonManagedReference
	private List<Product> products;
	
	public ProductLine() {
		super();
	}

	public ProductLine(String productLine, String textDescription, String htmlDescription, byte[] image,
			List<Product> products) {
		super();
		this.productLine = productLine;
		this.textDescription = textDescription;
		this.htmlDescription = htmlDescription;
		this.image = image;
		this.products = products;
	}

	public String getProductLine() {
		return productLine;
	}

	public void setProductLine(String productLine) {
		this.productLine = productLine;
	}

	public String getTextDescription() {
		return textDescription;
	}

	public void setTextDescription(String textDescription) {
		this.textDescription = textDescription;
	}

	public String getHtmlDescription() {
		return htmlDescription;
	}

	public void setHtmlDescription(String htmlDescription) {
		this.htmlDescription = htmlDescription;
	}

	public byte[] getImage() {
		return image;
	}

	public void setImage(byte[] image) {
		this.image = image;
	}

	public List<Product> getProducts() {
		return products;
	}

	public void setProducts(List<Product> products) {
		this.products = products;
	}

	@Override
	public String toString() {
		return "ProductLine [productLine=" + productLine + ", textDescription=" + textDescription + ", htmlDescription="
				+ htmlDescription + ", image=" + Arrays.toString(image) + ", products=" + products + "]";
	}
}
