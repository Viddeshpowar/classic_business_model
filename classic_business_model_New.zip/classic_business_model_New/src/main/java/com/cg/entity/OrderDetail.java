package com.cg.entity;

import java.math.BigDecimal;

import com.cg.entity.id.OrderDetailsId;
import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;

@Entity
@IdClass(OrderDetailsId.class)
@Table(name = "orderdetails")
public class OrderDetail {
	@Id
	@ManyToOne
	@JoinColumn(name = "orderNumber")
	@JsonBackReference(value = "orders-orderdetails")
	private Order orders;
	
	@Id
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "productCode")
	@JsonBackReference(value = "products-orderdetails")
	private Product products;
	
	@NotNull
	@Column(name = "quantityOrdered")
	private int quantityOrdered;
	
	@NotNull
	@Column(name = "priceEach", precision = 10, scale = 2)
	private BigDecimal priceEach;
	
	@NotNull
	@Column(name = "orderLineNumber")
	private short orderLineNumber;
	
	public OrderDetail() {
		super();
	}

	public OrderDetail(Order orders, Product products, @NotNull int quantityOrdered, @NotNull BigDecimal priceEach,
			@NotNull short orderLineNumber) {
		super();
		this.orders = orders;
		this.products = products;
		this.quantityOrdered = quantityOrdered;
		this.priceEach = priceEach;
		this.orderLineNumber = orderLineNumber;
	}

	public Order getOrders() {
		return orders;
	}

	public void setOrders(Order orders) {
		this.orders = orders;
	}

	public Product getProducts() {
		return products;
	}

	public void setProducts(Product products) {
		this.products = products;
	}

	public int getQuantityOrdered() {
		return quantityOrdered;
	}

	public void setQuantityOrdered(int quantityOrdered) {
		this.quantityOrdered = quantityOrdered;
	}

	public BigDecimal getPriceEach() {
		return priceEach;
	}

	public void setPriceEach(BigDecimal priceEach) {
		this.priceEach = priceEach;
	}

	public short getOrderLineNumber() {
		return orderLineNumber;
	}

	public void setOrderLineNumber(short orderLineNumber) {
		this.orderLineNumber = orderLineNumber;
	}

	@Override
	public String toString() {
		return "OrderDetail [orders=" + orders + ", products=" + products + ", quantityOrdered=" + quantityOrdered
				+ ", priceEach=" + priceEach + ", orderLineNumber=" + orderLineNumber + "]";
	}

	
}
