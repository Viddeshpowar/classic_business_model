package com.cg.entity.id;

import java.io.Serializable;

import com.cg.entity.Customer;

public class PaymentId implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;



	private Customer customers;

	private String checkNumber;
	
	public PaymentId() {
		super();
	}

	public PaymentId(Customer customers, String checkNumber) {
		super();
		this.customers = customers;
		this.checkNumber = checkNumber;
	}

	public Customer getCustomers() {
		return customers;
	}

	public void setCustomers(Customer customers) {
		this.customers = customers;
	}

	public String getCheckNumber() {
		return checkNumber;
	}

	public void setCheckNumber(String checkNumber) {
		this.checkNumber = checkNumber;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "PaymentId [customers=" + customers + ", checkNumber=" + checkNumber + "]";
	}

	
}
