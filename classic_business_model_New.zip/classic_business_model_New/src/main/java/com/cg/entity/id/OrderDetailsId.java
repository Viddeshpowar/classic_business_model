package com.cg.entity.id;

import java.io.Serializable;

import com.cg.entity.Order;
import com.cg.entity.Product;

public class OrderDetailsId implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Product products;
	
	private Order orders;
	
	public OrderDetailsId() {
		super();
	}

	public OrderDetailsId(Product products, Order orders) {
		super();
		this.products = products;
		this.orders = orders;
	}

	public Product getProducts() {
		return products;
	}

	public void setProducts(Product products) {
		this.products = products;
	}

	public Order getOrders() {
		return orders;
	}

	public void setOrders(Order orders) {
		this.orders = orders;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "OrderDetailsId [products=" + products + ", orders=" + orders + "]";
	}

	
}
