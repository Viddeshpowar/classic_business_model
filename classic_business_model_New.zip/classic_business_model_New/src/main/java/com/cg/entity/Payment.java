package com.cg.entity;

import java.math.BigDecimal;
import java.sql.Date;

import com.cg.entity.id.PaymentId;
import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;

@Entity
@Table(name = "payments")
@IdClass(PaymentId.class)
public class Payment {
	@Id
	@ManyToOne
	@JoinColumn(name = "customerNumber")
	@JsonBackReference(value = "customers-payments")
	private Customer customers;
	
	@Id
	@Column(name = "checkNumber",length = 50)
	private String checkNumber;
	
	@NotNull
    //@Pattern(regexp = "yyyy-MM-dd")
	@Column(name = "paymentDate")
	private Date paymentDate;
	
	@NotNull
	@Column(name = "amount", precision = 10, scale = 2)
	private BigDecimal amount;
	
	public Payment() {
		super();
	}

	public Payment(Customer customers, String checkNumber, @NotNull Date paymentDate, BigDecimal amount) {
		super();
		this.customers = customers;
		this.checkNumber = checkNumber;
		this.paymentDate = paymentDate;
		this.amount = amount;
	}

	public Customer getCustomers() {
		return customers;
	}

	public void setCustomers(Customer customers) {
		this.customers = customers;
	}

	public String getCheckNumber() {
		return checkNumber;
	}

	public void setCheckNumber(String checkNumber) {
		this.checkNumber = checkNumber;
	}

	public Date getPaymentDate() {
		return paymentDate;
	}

	public void setPaymentDate(Date paymentDate) {
		this.paymentDate = paymentDate;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	@Override
	public String toString() {
		return "Payment [customers=" + customers + ", checkNumber=" + checkNumber + ", paymentDate=" + paymentDate
				+ ", amount=" + amount + "]";
	}

	
}
