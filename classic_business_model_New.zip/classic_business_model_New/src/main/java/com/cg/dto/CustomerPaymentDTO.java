package com.cg.dto;

public class CustomerPaymentDTO {
	private int customerNumber;
	private String customerName;
	private String checkNumber;
	
	public CustomerPaymentDTO() {
		super();
	}

	public CustomerPaymentDTO(int customerNumber, String customerName, String checkNumber) {
		super();
		this.customerNumber = customerNumber;
		this.customerName = customerName;
		this.checkNumber = checkNumber;
	}

	public int getCustomerNumber() {
		return customerNumber;
	}

	public void setCustomerNumber(int customerNumber) {
		this.customerNumber = customerNumber;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCheckNumber() {
		return checkNumber;
	}

	public void setCheckNumber(String checkNumber) {
		this.checkNumber = checkNumber;
	}
	
	

}
