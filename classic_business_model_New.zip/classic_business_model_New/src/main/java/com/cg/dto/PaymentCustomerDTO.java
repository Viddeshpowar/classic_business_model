package com.cg.dto;

import com.cg.entity.Customer;
import com.cg.entity.Payment;

public class PaymentCustomerDTO {
	private Payment payment;
	private Customer customer;
	public PaymentCustomerDTO(Payment payment, Customer customer) {
		super();
		this.payment = payment;
		this.customer = customer;
	}
	public Payment getPayment() {
		return payment;
	}
	public void setPayment(Payment payment) {
		this.payment = payment;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
}
