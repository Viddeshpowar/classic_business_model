package com.cg.dto;

import com.cg.entity.Customer;
import com.cg.entity.Order;

public class CustomerOrderDTO {
	private Customer customer;
	private Order order;
	public CustomerOrderDTO(Order order,Customer customer) {
		super();
		this.order = order;
		this.customer = customer;
		
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public Order getOrder() {
		return order;
	}
	public void setOrder(Order order) {
		this.order = order;
	}
	
	
	

}
