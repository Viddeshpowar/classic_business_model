package com.cg.dto;

import java.math.BigDecimal;

public class ProductNameSaleAmountDTO {
	private String productName;
	private BigDecimal saleAmount;
	public ProductNameSaleAmountDTO(String productName, BigDecimal saleAmount) {
		super();
		this.productName = productName;
		this.saleAmount = saleAmount;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public BigDecimal getSaleAmount() {
		return saleAmount;
	}
	public void setSaleAmount(BigDecimal saleAmount) {
		this.saleAmount = saleAmount;
	}	

}
