package com.cg.service.impl;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dto.PaymentCustomerDTO;
import com.cg.entity.Customer;
import com.cg.entity.Office;
import com.cg.entity.Payment;
import com.cg.entity.id.PaymentId;
import com.cg.repository.PaymentRepository;
import com.cg.service.PaymentService;

@Service
public class PaymentServiceImpl implements PaymentService{
	@Autowired
	private PaymentRepository payRepo;
	
	@Override
	public Payment addPayment(int customerNumber, Payment payment) {
		// TODO Auto-generated method stub
		List<Payment> payments = payRepo.findByCustomerNumber(customerNumber);
		payments.add(payment);
		return payRepo.save(payment);
	}

	@Override
	public void updateCheckNumberOfCustomer(int customerNumber,String checkNumber, String newCheckNumber) {
		// TODO Auto-generated method stub
//		Customer customer = new Customer();
//		customer.setCustomerNumber(customerNumber);
//		
//		Payment payment = payRepo.findByCheckNumberAndCustomerNumber(customer, newCheckNumber);
//		System.out.println(payment);
//		PaymentId paymentId = new PaymentId(customer,checkNumber);
//		Payment payment =  payRepo.findById(paymentId).get();
		//payment.setCheckNumber(newCheckNumber);
		//payRepo.save(payment);
		payRepo.updateCheckNumberByCompositeKey(customerNumber, checkNumber, newCheckNumber);
	}

	@Override
	public void updateAmountOfCheckNumber(int customerNumber, String checkNumber, BigDecimal amount) {
		// TODO Auto-generated method stub
		payRepo.updateAmountByCompositeKey(customerNumber, checkNumber, amount);
	}

	@Override
	public List<PaymentCustomerDTO> findByCustomerNumber(int customerNumber) {
		return payRepo.findByCustomerNumberCustomerAndPayment(customerNumber);
		// TODO Auto-generated method stub
		
        //return payRepo.findByCustomerNumberCustomerAndPayment(customerNumber);
	}
	
	
	@Override
	public List<Map<String, Object>> findCustomerPaymentByCustomerNumber(int customerNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Payment> findByPaymentDate(Date paymentDate) {
		// TODO Auto-generated method stub
		return payRepo.findByPaymentDate(paymentDate);
	}

	@Override
	public Payment findByCheckNumber(String checkNumber) {
		// TODO Auto-generated method stub
		return payRepo.findByCheckNumber(checkNumber).get(0);
	}

	@Override
	public BigDecimal getTotalAmountByCustomerNumber(int customerNumber) {
		// TODO Auto-generated method stub
		return payRepo.findTotalAmountByCustomerNumber(customerNumber);
	}

	@Override
	public List<Customer> getCustomerByCheckNumber(String checkNumber) {
		// TODO Auto-generated method stub
		return payRepo.findCustomersByCheckNumber(checkNumber);
	}

	@Override
	public Customer getCustomerByMaxAmount() {
		// TODO Auto-generated method stub
		return payRepo.findCustomerWithMaxPayment();
	}

	@Override
	public List<Customer> getCustomerByPaymentDateRange(Date startpaymentDate, Date endpaymentDate) {
		// TODO Auto-generated method stub
		return payRepo.findCustomersByPaymentDateBetween(startpaymentDate, endpaymentDate);
	}

	@Override
	public List<Customer> getCustomerByPaymentDate(Date paymentDate) {
		// TODO Auto-generated method stub
		return payRepo.findCustomerByPaymentDate(paymentDate);
	}

	@Override
	public List<Office> getOfficeDetailsByMaxPaymentCollection() {
		// TODO Auto-generated method stub
		return payRepo.findOfficeWithMaxPaymentCollection();
	}

	
	
	//extra
	@Override
	public Payment getByCustomerNumberAndCheckNumber(int customerNumber, String checkNumber) {
		// TODO Auto-generated method stub
		Customer customer = new Customer();
		customer.setCustomerNumber(customerNumber);
		PaymentId paymentId = new PaymentId(customer,checkNumber);
		return payRepo.findById(paymentId).get();
//		return payRepo.findByCheckNumberAndCustomerNumber(customerNumber, checkNumber);
	}

	
	
	

}
