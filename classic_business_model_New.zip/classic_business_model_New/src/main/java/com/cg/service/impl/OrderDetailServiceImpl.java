package com.cg.service.impl;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.entity.OrderDetail;
import com.cg.repository.OrderDetailRepository;
import com.cg.service.OrderDetailService;
@Service
public class OrderDetailServiceImpl implements OrderDetailService{
	@Autowired
	private OrderDetailRepository orderDetailRepo;
	
	

	@Override
	public OrderDetail addOrderDetails(OrderDetail orderDetail) {
		// TODO Auto-generated method stub
		return orderDetailRepo.save(orderDetail);
	}



	@Override
	public OrderDetail updateQuantityOfOrderProduct(int orderNumber, String productCode, int quantityOrdered) {
		// TODO Auto-generated method stub
		OrderDetail orderDetail = orderDetailRepo.findByOrderNumberAndProductCode(orderNumber, productCode);
		orderDetail.setQuantityOrdered(quantityOrdered);
		orderDetailRepo.save(orderDetail);
		return orderDetail;
	}



	@Override
	public List<OrderDetail> getByOrderNumber(int orderNumber) {
		// TODO Auto-generated method stub
		return orderDetailRepo.findByOrderNumber(orderNumber);
	}
	

	@Override
	public BigDecimal getTotalAmountByOrderNumber(int orderNumber) {
		// TODO Auto-generated method stub
		return orderDetailRepo.getTotalAmountByOrderNumber(orderNumber);
	}


	@Override
	public int getByTotalSale() {
		// TODO Auto-generated method stub
		return orderDetailRepo.getTotalSale();
	}



	@Override
	public BigDecimal getOrderDetailsByMaxPriceOrder() {
		// TODO Auto-generated method stub
		return orderDetailRepo.getMaxPriceForOrder();
	}



	@Override
	public int getOrderDetailCountByOrderNumber(int orderNumber) {
		// TODO Auto-generated method stub
		return orderDetailRepo.getOrderDetailCountByOrderNumber(orderNumber);
	}






	

	
	

}

