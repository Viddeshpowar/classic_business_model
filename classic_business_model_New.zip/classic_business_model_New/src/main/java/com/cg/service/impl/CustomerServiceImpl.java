package com.cg.service.impl;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.entity.Customer;
import com.cg.repository.CustomerRepository;
import com.cg.service.CustomerService;

@Service
public class CustomerServiceImpl implements CustomerService{
	@Autowired
	private CustomerRepository customerRepo;
	
	
	@Override
	public List<Customer> findByEmployeeNumber(int employeeNumber) {
		// TODO Auto-generated method stub
		return customerRepo.findByEmployeeNumber(employeeNumber);
	}

	@Override
	public Customer addCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return customerRepo.save(customer);
	}

	@Override
	public List<Customer> findByCustomerName(String customerName) {
		// TODO Auto-generated method stub
		return customerRepo.findByCustomerName(customerName);
	}

	@Override
	public List<Customer> findByCity(String city) {
		// TODO Auto-generated method stub
		return customerRepo.findByCity(city);
	}

	@Override
	public Customer findByCustomerNumber(int customerNumber) {
		// TODO Auto-generated method stub
		return customerRepo.findByCustomerNumber(customerNumber).get(0);
	}

	@Override
	public List<Customer> findBySalesRepEmployeeNumber(int salesRepEmployeeNumber) {
		// TODO Auto-generated method stub
		return customerRepo.findCustomersBySalesRepEmployeeNumber(salesRepEmployeeNumber);
	}

	@Override
	public List<Customer> findByCities(String city) {
		// TODO Auto-generated method stub
		return customerRepo.findByCity(city);
	}
	
	
	@Override
	public List<Customer> findByCountry(String country) {
		// TODO Auto-generated method stub
		return customerRepo.findByCountry(country);
	}

	@Override
	public Customer findByPhoneNumber(String phone) {
		// TODO Auto-generated method stub
		return customerRepo.findByPhone(phone).get(0);
	}

	@Override
	public List<Customer> findByContactFirstName(String contactFirstName) {
		// TODO Auto-generated method stub
		return customerRepo.findByContactFirstName(contactFirstName);
	}

	@Override
	public List<Customer> findByContactLastName(String contactLastName) {
		// TODO Auto-generated method stub
		return customerRepo.findByContactLastName(contactLastName);
	}

	@Override
	public Customer updateNameOfCustomer(int customerNumber, String customerName) {
		// TODO Auto-generated method stub
		Customer customer = findByCustomerNumber(customerNumber);
		customer.setCustomerName(customerName);
		customerRepo.save(customer);
		return customer;
	}

	@Override
	public Customer updateLastNameOfCustomer(int customerNumber, String contactLastName) {
		// TODO Auto-generated method stub
		Customer customer = findByCustomerNumber(customerNumber);
		customer.setContactLastName(contactLastName);
		customerRepo.save(customer);
		return customer;
	}

	@Override
	public Customer updateFirstNameOfCustomer(int customerNumber, String contactFirstName) {
		// TODO Auto-generated method stub
		Customer customer = findByCustomerNumber(customerNumber);
		customer.setContactFirstName(contactFirstName);
		customerRepo.save(customer);
		return customer;
	}

	@Override
	public Customer updateAddressOfCustomer(int customerNumber, String addressLine1, String addressLine2) {
		// TODO Auto-generated method stub
		Customer customer = findByCustomerNumber(customerNumber);
		customer.setAddressLine1(addressLine1);
		customer.setAddressLine2(addressLine2);
		customerRepo.save(customer);
		return customer;
	}

	@Override
	public List<Customer> findByCreditLimit(BigDecimal creditLimit) {
		// TODO Auto-generated method stub
		return customerRepo.findByCreditLimit(creditLimit);
	}

	@Override
	public List<Customer> findByPostalCode(String postalCode) {
		// TODO Auto-generated method stub
		return customerRepo.findByPostalCode(postalCode);
	}

	@Override
	public List<Customer> findByCreditRange(BigDecimal start, BigDecimal end) {
		// TODO Auto-generated method stub
		return customerRepo.findCustomersByCreditLimitBetween(start, end);
	}

	@Override
	public List<Customer> getByFirstName(String firstName) {
		return customerRepo.findByCustomerNameLike(firstName);
		// TODO Auto-generated method stub
//		return customerRepo.findByCustomerNameRegex(firstName);
	}

	@Override
	public List<Customer> getByGreaterCreditLimit(BigDecimal creditLimit) {
		// TODO Auto-generated method stub
		return customerRepo.findByCreditLimitGreaterThan(creditLimit);
	}

	@Override
	public List<Customer> getByLowerCreditLimit(BigDecimal creditLimit) {
		// TODO Auto-generated method stub
		return customerRepo.findByCreditLimitLessThan(creditLimit);
	}

	

}
