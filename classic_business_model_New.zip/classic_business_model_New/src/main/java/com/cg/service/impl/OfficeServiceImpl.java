package com.cg.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.entity.Customer;
import com.cg.entity.Office;
import com.cg.repository.OfficeRepository;
import com.cg.service.OfficeService;

@Service
public class OfficeServiceImpl implements OfficeService{
	
	@Autowired
	private OfficeRepository officeRepo;
	

	@Override
	public Office addOffice(Office office) {
		// TODO Auto-generated method stub
		return officeRepo.save(office);
	}

	@Override
	public Office findByCode(String officeCode) {
		// TODO Auto-generated method stub
		List<Office> office = officeRepo.findByOfficeCode(officeCode);
		if(office.size()>0) {
			return office.get(0);
		}else {
			return null;
		}
	}

	@Override
	public Office updatePhoneNo(String officeCode, String phoneNo) {
		// TODO Auto-generated method stub
		Office office = findByCode(officeCode);
		office.setPhone(phoneNo);
		officeRepo.save(office);
		return office;
	}

	@Override
	public Office updateOfficeAddress(String officeCode, String addressLine1, String addressLine2) {
		// TODO Auto-generated method stub
		Office office = findByCode(officeCode);
		office.setAddressLine1(addressLine1);
		office.setAddressLine2(addressLine2);
		officeRepo.save(office);
		return office;
	}

	@Override
	public List<Customer> getAllCustomersOfofficeCode(String officeCode) {
		// TODO Auto-generated method stub
		return officeRepo.findCustomersByOfficeCode(officeCode);
	}

	@Override
	public List<Office> getAllOfficesOfCities(List<String> city) {
		// TODO Auto-generated method stub
		
		return officeRepo.findOfficesByCityNames(city);
	}
}
