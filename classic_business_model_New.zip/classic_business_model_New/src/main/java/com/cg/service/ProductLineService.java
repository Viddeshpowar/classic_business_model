package com.cg.service;

import com.cg.entity.ProductLine;

public interface ProductLineService {
	
	
	
	public ProductLine addNewProductLine(ProductLine productLine);
	public void updateTextDescriptionByProductLine(String productLine, String textDescription);

	
 
}
