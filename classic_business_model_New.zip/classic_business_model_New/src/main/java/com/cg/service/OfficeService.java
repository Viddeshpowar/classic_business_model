package com.cg.service;

import java.util.List;

import com.cg.entity.Customer;
import com.cg.entity.Office;

public interface OfficeService {
	public Office addOffice(Office office);
	public Office findByCode(String officeCode);
	public Office updatePhoneNo(String officeCode, String phoneNo);
	public Office updateOfficeAddress(String officeCode, String addressLine1, String addressLine2);
	public List<Customer> getAllCustomersOfofficeCode(String officeCode);
	public List<Office> getAllOfficesOfCities(List<String> city);
}
