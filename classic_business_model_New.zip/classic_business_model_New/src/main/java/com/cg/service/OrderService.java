package com.cg.service;

import java.sql.Date;
import java.util.List;

import com.cg.dto.CustomerOrderDTO;
import com.cg.dto.ProductProductLineDTO;
import com.cg.entity.Order;
import com.cg.entity.OrderDetail;
import com.cg.entity.Product;

public interface OrderService {

	public Order addOrder(Order order);

	public Order updateOrderShippedDate(Integer orderNumber, Date shippedDate);

	public Order updateOrderStatus(Integer orderNumber, String status);
	
	public List<CustomerOrderDTO> getOrdersByCustomerNumber(int customerNumber);

	public Order getById(Integer orderNumber);

	public List<Order> getOrdersByOrderDate(Date orderDate);

	public List<Order> getOrdersByRequiredDate(Date requiredDate);

	public List<Order> getOrdersByShippedDate(Date shippedDate);

	public List<OrderDetail> getOrdersByStatus(String status);
	
	public List<OrderDetail> getOrderDetailsByStatusForCustomer(int customerNumber, String status);
	
	public List<Product> getProductByOrderNumber(int orderNumber);
	
	public List<String> getProductNamesByOrderNumber(int orderNumber);
	
	public List<Product> getAllProductsForAllOrders();
	
	public List<Order> getAllOrdersWithStatusAndSameShippedAndDeliveredDate(String status);
	
	public List<ProductProductLineDTO> getAllProductWithProductLineOnSpecificShippedDate(Date date);
	
}
