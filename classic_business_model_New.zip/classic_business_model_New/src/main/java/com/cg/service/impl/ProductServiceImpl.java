package com.cg.service.impl;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dto.ProductNameSaleAmountDTO;
import com.cg.entity.Product;
import com.cg.repository.ProductRepository;
import com.cg.service.ProductService;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	private ProductRepository productRepo;

	@Override
	public Product addProduct(Product product) {
		// TODO Auto-generated method stub
		return productRepo.save(product);
	}
	
	

	@Override
	public Product updateBuyPrice(String productCode, BigDecimal buyPrice) {
		// TODO Auto-generated method stub
		Product product = findByCode(productCode);
		product.setBuyPrice(buyPrice);
		productRepo.save(product);
		return product;
	}

	@Override
	public Product updateQuantityInStock(String productCode, short quantityInStock) {
		// TODO Auto-generated method stub
		Product product = findByCode(productCode);
		product.setQuantityInStock(quantityInStock);
		productRepo.save(product);
		return product;
	}

	@Override
	public Product updateMsrp(String productCode, BigDecimal msrp) {
		// TODO Auto-generated method stub
		Product product = findByCode(productCode);
		product.setMsrp(msrp);
		productRepo.save(product);
		return product;
	}

	@Override
	public Product updateProductVendor(String productCode, String productVendor) {
		// TODO Auto-generated method stub
		Product product = findByCode(productCode);
		product.setProductVendor(productVendor);
		productRepo.save(product);
		return product;
	}

	@Override
	public Product updateProductScale(String productCode, String productScale) {
		// TODO Auto-generated method stub
		Product product = findByCode(productCode);
		product.setProductScale(productScale);
		productRepo.save(product);
		return product;
	}

	@Override
	public Product updateProductName(String productCode, String productName) {
		// TODO Auto-generated method stub
		Product product = findByCode(productCode);
		product.setProductName(productName);
		productRepo.save(product);
		return product;
	}

	
	@Override
	public Product findByCode(String productCode) {
		// TODO Auto-generated method stub
		List<Product> product = productRepo.findByProductCode(productCode);
		if(product.size()>0) {
			return product.get(0);
		}else {
			return null;
		}
	}
	

	@Override
	public List<Product> getProductsByName(String productName) {
		// TODO Auto-generated method stub
		return productRepo.findByProductName(productName);
	}

	@Override
	public List<Product> getProductsByScale(String productScale) {
	    return productRepo.findByProductScale(productScale);
	}


	@Override
	public List<Product> getProductsByVendor(String productVendor) {
		return productRepo.findByProductVendor(productVendor);
	}
	
	@Override
    public int getTotalOrderedQuantityByProductCode(String productCode) {
        return productRepo.getTotalSaleForGivenProductCode(productCode);
    }


	@Override
	public BigDecimal getTotalSaleAmountForProduct(String productCode) {
		// TODO Auto-generated method stub
		return productRepo.getTotalSaleAmountForGivenProductCode(productCode);
	}



	@Override
	public List<ProductNameSaleAmountDTO> getTotalSaleAmountForEachProducts() {
		// TODO Auto-generated method stub
		return productRepo.getTotalSaleAmountForEachProduct();
	}
	


	@Override
	public List<Product> getHighlyDemandedProducts() {
		return productRepo.getHighlyDemandedProducts();
	}

}
