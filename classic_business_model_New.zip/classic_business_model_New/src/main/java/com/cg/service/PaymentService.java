package com.cg.service;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.List;
import java.util.Map;

import com.cg.dto.PaymentCustomerDTO;
import com.cg.entity.Customer;
import com.cg.entity.Office;
import com.cg.entity.Payment;

public interface PaymentService {
	public Payment addPayment(int customerNumber, Payment payment);
	public void updateCheckNumberOfCustomer(int customerNumber, String checkNumber, String newCheckNumber);
	public void updateAmountOfCheckNumber(int customerNumber, String checkNumber, BigDecimal amount);
	//dto
	public List<PaymentCustomerDTO> findByCustomerNumber(int customerNumber);
	List<Payment> findByPaymentDate(Date paymentDate);
	public Payment findByCheckNumber(String checkNumber);
	public BigDecimal getTotalAmountByCustomerNumber(int customerNumber);
	public List<Customer> getCustomerByCheckNumber(String checkNumber);
	public Customer getCustomerByMaxAmount();
	public List<Customer> getCustomerByPaymentDateRange(Date startpaymentDate, Date endpaymentDate);
	public List<Customer> getCustomerByPaymentDate(Date paymentDate);
	public List<Office> getOfficeDetailsByMaxPaymentCollection();
	
	
	public List<Map<String, Object>> findCustomerPaymentByCustomerNumber(int customerNumber);
	
	
	//extra
	public Payment getByCustomerNumberAndCheckNumber(int customerNumber, String checkNumber);

}