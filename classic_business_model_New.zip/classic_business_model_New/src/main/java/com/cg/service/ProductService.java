package com.cg.service;

import java.math.BigDecimal;
import java.util.List;

import com.cg.dto.ProductNameSaleAmountDTO;
import com.cg.entity.Product;

public interface ProductService {

	public Product addProduct(Product product);
	public Product updateBuyPrice(String productCode, BigDecimal buyPrice);
	public Product updateQuantityInStock(String productCode, short quantityInStock);
	public Product updateMsrp(String productCode, BigDecimal msrp);
	public Product updateProductVendor(String productCode, String productVendor);
	public Product updateProductScale(String productCode, String productScale);
	public Product updateProductName(String productCode, String productName);
	
	public Product findByCode(String productCode);

	public List<Product> getProductsByName(String productName);

	public List<Product> getProductsByScale(String productScale);

	public List<Product> getProductsByVendor(String productVendor);
	
	int getTotalOrderedQuantityByProductCode(String productCode);
	
	public BigDecimal getTotalSaleAmountForProduct(String productCode);

	public List<ProductNameSaleAmountDTO> getTotalSaleAmountForEachProducts();
	
	//not done
	public List<Product> getHighlyDemandedProducts();


}
