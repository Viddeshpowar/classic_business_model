package com.cg.service;

import java.math.BigDecimal;
import java.util.List;

import com.cg.entity.OrderDetail;


public interface OrderDetailService {
	public OrderDetail addOrderDetails(OrderDetail orderDetail);
	public OrderDetail updateQuantityOfOrderProduct(int orderNumber, String productCode, int quantityOrdered);
	public List<OrderDetail> getByOrderNumber(int orderNumber);
	public BigDecimal getTotalAmountByOrderNumber(int orderNumber);
	public int getByTotalSale();
	public BigDecimal getOrderDetailsByMaxPriceOrder();
	public int getOrderDetailCountByOrderNumber(int orderNumber);

}