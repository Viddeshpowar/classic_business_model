package com.cg.service.impl;


import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dto.CustomerOrderDTO;
import com.cg.dto.ProductProductLineDTO;
import com.cg.entity.Order;
import com.cg.entity.OrderDetail;
import com.cg.entity.Product;
import com.cg.repository.OrderRepository;
import com.cg.service.OrderService;

@Service

public class OrderServiceImpl implements OrderService {
	private OrderRepository orderRepository;

	@Autowired

	public OrderServiceImpl(OrderRepository orderRepository) {
		this.orderRepository = orderRepository;

	}
	@Override
	public Order addOrder(Order order) {
        return orderRepository.save(order);
    }

	@Override

	public Order updateOrderShippedDate(Integer orderNumber, Date shippedDate) {
		Order order = orderRepository.findById(orderNumber).get();
		if (order != null) {
			order.setShippedDate(shippedDate);
			orderRepository.save(order);

		}
		return order;
	}

	@Override

	public Order updateOrderStatus(Integer orderNumber, String status) {
		Order order = orderRepository.findById(orderNumber).get();
		if (order != null) {
			order.setStatus(status);
			orderRepository.save(order);
		}

		return order;
	}

	@Override

	public Order getById(Integer orderNumber) {
		return orderRepository.findById(orderNumber).get();

	}

	@Override
	public List<Order> getOrdersByOrderDate(Date orderDate) {
		return orderRepository.findByOrderDate(orderDate);

	}

	@Override
	public List<Order> getOrdersByRequiredDate(Date requiredDate) {
		return orderRepository.findByRequiredDate(requiredDate);

	}

	@Override
	public List<Order> getOrdersByShippedDate(Date shippedDate) {
		return orderRepository.findByShippedDate(shippedDate);

	}

	@Override
	public List<OrderDetail> getOrdersByStatus(String status) {
		return orderRepository.findByStatus(status);

	}
	@Override
	public List<CustomerOrderDTO> getOrdersByCustomerNumber(int customerNumber) {
		// TODO Auto-generated method stub
		return orderRepository.findOrderDetailByCustomerNumber(customerNumber);
	}
	@Override
	public List<OrderDetail> getOrderDetailsByStatusForCustomer(int customerNumber, String status) {
		// TODO Auto-generated method stub
		return orderRepository.findOrderDetailByCustomerNumberAndStatus(status, customerNumber);
	}
	@Override
	public List<Product> getProductByOrderNumber(int orderNumber) {
		// TODO Auto-generated method stub
		return orderRepository.findProductDetailByOrderNumber(orderNumber);
	}
	@Override
	public List<String> getProductNamesByOrderNumber(int orderNumber) {
		// TODO Auto-generated method stub
		return orderRepository.findProductNameByOrderNumber(orderNumber);
	}
	@Override
	public List<Product> getAllProductsForAllOrders() {
		// TODO Auto-generated method stub
		return orderRepository.findAllProductForAllOrderDetail();
	}
	@Override
	public List<Order> getAllOrdersWithStatusAndSameShippedAndDeliveredDate(String status) {
		// TODO Auto-generated method stub
		return orderRepository.findOrderBySameDateAndDeliveredStatus(status);
	}
	@Override
	public List<ProductProductLineDTO> getAllProductWithProductLineOnSpecificShippedDate(Date date) {
		// TODO Auto-generated method stub
		return orderRepository.findProductAndProductLineDetailsByShipmentDate(date);
	}

}
