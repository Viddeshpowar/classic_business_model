package com.cg.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.entity.Employee;
import com.cg.entity.Office;
import com.cg.repository.EmployeeRepository;
import com.cg.repository.OfficeRepository;
import com.cg.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService{
	
	@Autowired
	private EmployeeRepository empRepo;
	
	@Autowired
	private OfficeRepository officeRepo;


	@Override
	public Employee createEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return empRepo.save(employee);
	}

	@Override
	public Employee updateReporting(int empId, int empNewNo) {
		// TODO Auto-generated method stub
		Employee employee = findById(empId);
		Employee newEmployee = findById(empNewNo);
		employee.setReportsTo(newEmployee);
		empRepo.save(employee);
		return employee;
	}

	@Override
	public Employee updateRole(int empId, String role) {
		// TODO Auto-generated method stub
		Employee employee = findById(empId);
		employee.setJobTitle(role);
		empRepo.save(employee);
		return employee;
	}

	@Override
	public Employee assignOffice(int empId, String officeCode) {
		List<Office> offices = officeRepo.findByOfficeCode(officeCode);
		if (!offices.isEmpty()) {
		    Office office = offices.get(0); // Choose the first office (you can implement a different logic here)
		    Employee employee = findById(empId);
		    employee.setOffices(office);
		    empRepo.save(employee);
		    return employee;
		} else {
		    // Handle the case where no office with the given code was found.
		    return null;
		}
	}

	@Override
	public Employee findById(int id) {
		// TODO Auto-generated method stub
		return empRepo.findById(id).orElse(null);
	}

	@Override
	public List<Employee> getAll() {
		// TODO Auto-generated method stub
		return empRepo.findAll();
	}

	@Override
	public List<Employee> getByOfficeCode(String officeCode) {
		// TODO Auto-generated method stub
		return empRepo.findByOfficeCode(officeCode);
	}

	@Override
	public List<Employee> getByCity(String city) {
		// TODO Auto-generated method stub
		return empRepo.findByOfficeCity(city);
	}

}
