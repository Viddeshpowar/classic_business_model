package com.cg.service;

import java.util.List;

import com.cg.entity.Employee;

public interface EmployeeService {
	public Employee createEmployee(Employee employee);
	public Employee updateReporting(int empId, int empNewNo);
	public Employee updateRole(int empId, String role);
	public Employee assignOffice(int empId,String officeCode);
	public Employee findById(int id);
	public List<Employee> getAll();
	public List<Employee> getByOfficeCode(String officeCode);
	public List<Employee> getByCity(String city);
}
