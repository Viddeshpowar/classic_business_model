package com.cg.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.entity.ProductLine;
import com.cg.repository.ProductLineRepository;
import com.cg.service.ProductLineService;

@Service
public class ProductLineServiceImpl implements ProductLineService {
	@Autowired
	private ProductLineRepository productLineRepo;

	
	@Override
	public ProductLine addNewProductLine(ProductLine productLine) {
		return productLineRepo.save(productLine);
	}

	
	@Override
	public void updateTextDescriptionByProductLine(String productLine, String textDescription) {
		productLineRepo.updateProductLine(productLine,textDescription);
	}




}
