package com.cg.service;

import java.math.BigDecimal;
import java.util.List;

import com.cg.entity.Customer;

public interface CustomerService {
	public List<Customer> findByEmployeeNumber(int EmployeeNumber);
	
	
	public Customer addCustomer(Customer customer);
	public List<Customer> findByCustomerName(String customerName);
	public List<Customer> findByCity(String city);
	public Customer findByCustomerNumber(int customerNumber);
	public List<Customer> findBySalesRepEmployeeNumber(int salesRepEmployeeNumber);
	public List<Customer> findByCities(String city); //double
	public List<Customer> findByCountry(String country);
	public Customer findByPhoneNumber(String phone);
	public List<Customer> findByContactFirstName(String contactFirstName);
	public List<Customer> findByContactLastName(String contactLastName);
	public Customer updateNameOfCustomer(int customerNumber, String customerName);
	public Customer updateLastNameOfCustomer(int customerNumber, String contactLastName);
	public Customer updateFirstNameOfCustomer(int customerNumber, String contactFirstName);
	public Customer updateAddressOfCustomer(int customerNumber, String addressLine1, String addressLine2);
	public List<Customer> findByCreditLimit(BigDecimal creditLimit);
	public List<Customer> findByPostalCode(String postalCode);
	public List<Customer> findByCreditRange(BigDecimal start, BigDecimal end);
	//public List<Customer> findByPageNo(PageSize pageno sortBy sortDir);
	public List<Customer> getByFirstName(String contactFirstName);
	public List<Customer> getByGreaterCreditLimit(BigDecimal creditLimit);
	public List<Customer> getByLowerCreditLimit(BigDecimal creditLimit);
	//public List<Customer> findBy
}
