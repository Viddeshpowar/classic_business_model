package com.cg.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.entity.ProductLine;

import jakarta.transaction.Transactional;

public interface ProductLineRepository extends JpaRepository<ProductLine,String>{
	
	@Modifying
    @Transactional
	@Query("UPDATE ProductLine p SET p.textDescription = :textDescription " +
	           "WHERE p.productLine = :productLine ")
	void updateProductLine(@Param("productLine") String productLine, @Param("textDescription") String textDescription);

}
