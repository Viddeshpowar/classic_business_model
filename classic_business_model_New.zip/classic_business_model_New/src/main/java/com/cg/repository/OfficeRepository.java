package com.cg.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.entity.Customer;
import com.cg.entity.Office;

@Repository
public interface OfficeRepository extends JpaRepository<Office, Integer>{
	List<Office> findByOfficeCode(String officeCode);
	
//	@Query("SELECT e FROM Employee e WHERE e.offices.officeCode = :officeCode")
//	List<Employee> findEmployeesByOfficeCode(@Param("officeCode") String officeCode);

	@Query("SELECT o FROM Office o WHERE o.city IN :cityNames")
    List<Office> findOfficesByCityNames(@Param("cityNames") List<String> cityNames);

	@Query("SELECT e.customers FROM Employee e JOIN e.offices o WHERE o.officeCode = :officeCode")
    List<Customer> findCustomersByOfficeCode(@Param("officeCode") String officeCode);
}
