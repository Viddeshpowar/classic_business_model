package com.cg.repository;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.entity.Customer;
import com.cg.entity.Employee;




public interface CustomerRepository extends JpaRepository<Customer, Integer>{
	
	
	
	@Query("SELECT c FROM Customer c JOIN c.salesRepEmployeeNumber e WHERE e.employeeNumber = :employeeNumber")
    List<Customer> findByEmployeeNumber(@Param("employeeNumber") int employeeNumber);
	
	List<Customer> findByCustomerName(String customerName);
	
	List<Customer> findByCity(String city);
	
	List<Customer> findByCustomerNumber(int customerNumber);
	
	List<Customer> findBySalesRepEmployeeNumber(Employee salesRepEmployeeNumber);
	
	@Query("SELECT c FROM Customer c WHERE c.salesRepEmployeeNumber.employeeNumber = :salesRepEmployeeNumber")
	List<Customer> findCustomersBySalesRepEmployeeNumber(@Param("salesRepEmployeeNumber") int salesRepEmployeeNumber);
	
	List<Customer> findByCountry(String country);
	
	List<Customer> findByPhone(String phone);
	
	List<Customer> findByContactFirstName(String contactFirstName);
	
	List<Customer> findByContactLastName(String contactLastName);
	
	List<Customer> findByCreditLimit(BigDecimal creditLimit);
	
	List<Customer> findByPostalCode(String postalCode);
	
	@Query("SELECT c FROM Customer c WHERE c.creditLimit BETWEEN :start AND :end")
	List<Customer> findCustomersByCreditLimitBetween(@Param("start") BigDecimal start, @Param("end") BigDecimal end);
	
	//@Query("SELECT c FROM Customer c WHERE c.customerName LIKE CONCAT('%', :firstNameSubstring, '%')")
//    List<Customer> findByCustomerNameContainingIgnoreCase(@Param("firstNameSubstring") String firstNameSubstring);
	
//	@Query("SELECT c FROM Customer c WHERE REGEXP(c.customerName, :regexPattern) = true")
//	List<Customer> findByCustomerNameRegex(@Param("regexPattern") String regexPattern);
	List<Customer> findByCustomerNameLike(String fn);
	
	List<Customer> findByCreditLimitGreaterThan(BigDecimal creditLimit);
	
	List<Customer> findByCreditLimitLessThan(BigDecimal creditLimit);


	

	
	
}
