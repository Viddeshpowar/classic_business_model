package com.cg.repository;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.dto.ProductNameSaleAmountDTO;
import com.cg.entity.Product;

public interface ProductRepository extends JpaRepository<Product, String> {
	List<Product> findByProductCode(String productCode);

	List<Product> findByProductName(String productName);

	List<Product> findByProductScale(String productScale);

	List<Product> findByProductVendor(String productVendor);

	@Query("SELECT SUM(o.quantityOrdered) FROM OrderDetail o JOIN o.products p WHERE p.productCode = :productCode")
	int getTotalSaleForGivenProductCode(@Param("productCode") String productCode);

	@Query("SELECT SUM(o.quantityOrdered * o.priceEach) FROM OrderDetail o JOIN o.products p WHERE p.productCode = :productCode")
	BigDecimal getTotalSaleAmountForGivenProductCode(@Param("productCode") String productCode);
	
	@Query("SELECT NEW com.cg.dto.ProductNameSaleAmountDTO(p.productName, SUM(o.quantityOrdered * o.priceEach)) FROM OrderDetail o JOIN o.products p GROUP BY p.productName")
	List<ProductNameSaleAmountDTO> getTotalSaleAmountForEachProduct();

	//error
	@Query("SELECT o.products FROM OrderDetail o WHERE o.quantityOrdered = (SELECT MAX(o2.quantityOrdered) FROM OrderDetail o2)")
	List<Product> getHighlyDemandedProducts();

}
