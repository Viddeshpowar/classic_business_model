package com.cg.repository;

import java.sql.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.dto.CustomerOrderDTO;
import com.cg.dto.ProductProductLineDTO;
import com.cg.entity.Order;
import com.cg.entity.OrderDetail;
import com.cg.entity.Product;

public interface OrderRepository extends JpaRepository<Order, Integer> {
	
	List<Order> findByOrderDate(Date orderDate);

	List<Order> findByRequiredDate(Date requiredDate);

	List<Order> findByShippedDate(Date shippedDate);

	List<OrderDetail> findByStatus(String status);
	
	@Query("SELECT NEW com.cg.dto.CustomerOrderDTO(o, o.customers) FROM Order o WHERE o.customers.customerNumber = :customerNumber")
	List<CustomerOrderDTO> findOrderDetailByCustomerNumber(@Param("customerNumber") int customerNumber);
	
	
	@Query("SELECT od FROM OrderDetail od JOIN od.orders o JOIN o.customers c WHERE o.status = :status AND c.customerNumber = :customerNumber")
	List<OrderDetail> findOrderDetailByCustomerNumberAndStatus(@Param("status") String Status,@Param("customerNumber") int customerNumber);
	
	@Query("SELECT od.products FROM OrderDetail od WHERE od.orders.orderNumber = :orderNumber")
	List<Product> findProductDetailByOrderNumber(@Param("orderNumber") int orderNumber);
	
	@Query("SELECT od.products.productName FROM OrderDetail od WHERE od.orders.orderNumber = :orderNumber")
	List<String> findProductNameByOrderNumber(@Param("orderNumber") int orderNumber);
	
	@Query("SELECT od.products FROM OrderDetail od")
	List<Product> findAllProductForAllOrderDetail();
	
	@Query("SELECT o FROM Order o WHERE o.shippedDate = o.requiredDate AND o.status = :status")
	List<Order> findOrderBySameDateAndDeliveredStatus(@Param("status") String status);
	
	@Query("SELECT NEW com.cg.dto.ProductProductLineDTO(od.products, od.products.productlines) " +
		       "FROM OrderDetail od " +
		       "WHERE od.orders.shippedDate = :shippedDate")
	List<ProductProductLineDTO> findProductAndProductLineDetailsByShipmentDate(@Param("shippedDate") Date shippedDate);


}