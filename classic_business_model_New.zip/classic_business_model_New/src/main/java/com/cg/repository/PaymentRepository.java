package com.cg.repository;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.dto.PaymentCustomerDTO;
import com.cg.entity.Customer;
import com.cg.entity.Office;
import com.cg.entity.Payment;
import com.cg.entity.id.PaymentId;

import jakarta.transaction.Transactional;

@Repository
public interface PaymentRepository extends JpaRepository<Payment, PaymentId > {
	List<Payment> findByCustomers(Customer customers);
	
	@Query("SELECT NEW com.cg.dto.PaymentCustomerDTO(p, p.customers) FROM Payment p WHERE p.customers.customerNumber = :customerNumber")
	List<PaymentCustomerDTO> findByCustomerNumberCustomerAndPayment(@Param("customerNumber") int customerNumber);

	
	

	
	@Query("SELECT p FROM Payment p JOIN p.customers c WHERE c.customerNumber = :customerNumber")
	List<Payment> findByCustomerNumber(@Param("customerNumber") int customerNumber);


	List<Payment> findByCheckNumber(String checkNumber);
	
//	@Query("SELECT p FROM Payment p JOIN p.customers c WHERE c = :customers AND p.checkNumber = :checkNumber")
//	Payment findByCheckNumberAndCustomerNumber(@Param("customers")Customer customers,@Param("checkNumber")String checkNumber);
	
	
	@Modifying
    @Transactional
	@Query("UPDATE Payment p SET p.checkNumber = :newCheckNumber " +
	           "WHERE p.customers.customerNumber = :customerNumber " +
	           "AND p.checkNumber = :checkNumber")
	void updateCheckNumberByCompositeKey(int customerNumber, String checkNumber, String newCheckNumber);
	
	@Modifying
    @Transactional
	@Query("UPDATE Payment p SET p.amount = :amount " +
	           "WHERE p.customers.customerNumber = :customerNumber " +
	           "AND p.checkNumber = :checkNumber")
	void updateAmountByCompositeKey(int customerNumber, String checkNumber, BigDecimal amount);
	
	
	List<Payment> findByPaymentDate(Date paymentDate);
	
	@Query("SELECT SUM(p.amount) FROM Payment p JOIN p.customers c WHERE c.customerNumber = :customerNumber")
	BigDecimal findTotalAmountByCustomerNumber(@Param("customerNumber") int customerNumber);

	@Query("SELECT p.customers FROM Payment p WHERE p.checkNumber = :checkNumber")
	List<Customer> findCustomersByCheckNumber(@Param("checkNumber") String checkNumber);
	
	
	@Query("SELECT p.customers FROM Payment p " + 
	       "WHERE p.amount = (SELECT MAX(p2.amount) FROM Payment p2)")
	Customer findCustomerWithMaxPayment();

	
	@Query("SELECT p.customers FROM Payment p WHERE p.paymentDate BETWEEN :startDate AND :endDate")
	List<Customer> findCustomersByPaymentDateBetween(@Param("startDate") Date startDate, @Param("endDate") Date endDate);

	
	@Query("SELECT p.customers FROM Payment p WHERE p.paymentDate = :paymentDate")
	List<Customer> findCustomerByPaymentDate(@Param("paymentDate") Date paymentDate);

	
	@Query("SELECT o FROM Office o " +
	           "WHERE o.officeCode IN " +
	           "(SELECT e.offices.officeCode FROM Employee e " +
	           "JOIN e.customers c " +
	           "JOIN c.payments p " +
	           "GROUP BY e.offices.officeCode " +
	           "ORDER BY SUM(p.amount) DESC)")
	    List<Office> findOfficeWithMaxPaymentCollection();

	
//	@Query("SELECT p FROM Payment p JOIN  FETCH p.customer c WHERE c.customerNumber = :customerNumber")
//	List<Payment> findByCustomerNumberAllDetails(@Param("customerNumber") int customerNumber);

	
//	@Query("SELECT p FROM Payment p"+
//	       "WHERE p.customers.customerNumber = :customerNumber " +
//	       "AND p.checkNumber = :checkNumber")
//	Payment findByCheckNumberAndCustomerNumber(int customerNumber, String checkNumber);
}
