package com.cg.repository;


import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.entity.OrderDetail;
import com.cg.entity.id.OrderDetailsId;

public interface OrderDetailRepository extends JpaRepository<OrderDetail, OrderDetailsId>{


	@Query("SELECT od FROM OrderDetail od WHERE od.orders.orderNumber = :orderNumber")
	List<OrderDetail> findByOrderNumber(@Param("orderNumber") int orderNumber);
	
	
	@Query
	("SELECT oe FROM OrderDetail oe WHERE oe.orders.orderNumber = :orderNumber AND oe.products.productCode = :productCode")
    OrderDetail findByOrderNumberAndProductCode(@Param("orderNumber") int orderNumber, @Param("productCode") String productCode);
	

	 @Query("SELECT SUM(p.amount) " +            
			 "FROM Payment p " +            
			 "JOIN p.customers c " +            
			 "JOIN c.orders o " +            
			 "WHERE o.orderNumber = :orderNumber")
	 BigDecimal getTotalAmountByOrderNumber(@Param("orderNumber") int orderNumber);
	 
	 @Query
	 ("SELECT SUM(o.quantityOrdered) FROM OrderDetail o")
	 int getTotalSale();
	 
	 
	 @Query
	 ("SELECT MAX(od.priceEach) FROM OrderDetail od")
	 BigDecimal getMaxPriceForOrder();
	 
	 @Query
	 ("SELECT COUNT(od) FROM OrderDetail od WHERE od.orders.orderNumber = :orderNumber")
	 int getOrderDetailCountByOrderNumber(int orderNumber);

	

	

	
	
}

