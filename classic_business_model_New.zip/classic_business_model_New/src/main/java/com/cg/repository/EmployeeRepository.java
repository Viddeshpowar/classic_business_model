package com.cg.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.entity.Employee;
import com.cg.entity.Office;



public interface EmployeeRepository extends JpaRepository<Employee, Integer>{
	List<Employee> findByOffices(Office offices);
	
	@Query("SELECT e FROM Employee e JOIN e.offices o WHERE o.city = :city")
	List<Employee> findByOfficeCity(@Param("city") String city);
	
	@Query("select e from Employee e join e.offices o where o.officeCode = :officeCode")
	List<Employee> findByOfficeCode(@Param("officeCode") String officeCode);
	
	
}
